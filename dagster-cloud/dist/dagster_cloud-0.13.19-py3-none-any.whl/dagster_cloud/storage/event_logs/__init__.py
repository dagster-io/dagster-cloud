from .storage import GraphQLEventLogStorage
