SYSTEM_TAG_PREFIX = "dagster-cloud/"

ALERT_EMAILS_TAG = f"{SYSTEM_TAG_PREFIX}alert_emails"
