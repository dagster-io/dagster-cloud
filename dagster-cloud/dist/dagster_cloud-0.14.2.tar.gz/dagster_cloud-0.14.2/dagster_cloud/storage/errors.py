class GraphQLStorageError(Exception):
    """Raise this when there's an error in the GraphQL layer"""
